import amqp from "amqplib";
export const handler = async (event) => {
  const bucket = event.Records[0].s3.bucket.name;
  const key = decodeURIComponent(
    event.Records[0].s3.object.key.replace(/\+/g, " ")
  );
  try {
    const client = await amqp.connect(process.env.RABBITMQ_URL);
    const channel = await client.createChannel();
    const queueName = "video-transcoder";
    await channel.assertQueue(queueName, { durable: true });
    const messageBuffer = Buffer.from(JSON.stringify({ bucket, key }));
    channel.sendToQueue(queueName, messageBuffer, {
      persistent: true,
    });
    await channel.close();
    await client.close();
  } catch (error) {
    console.error("Error in connecting to RabbitMQ", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "RabbitMQ Error", detail: error.message }),
    };
  }
  return {
    statusCode: 200,
    body: JSON.stringify({ status: "OK" }),
  };
};
